<?php
$link = mysql_connect('localhost', 'root', '');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
$dbname="counties";
mysql_select_db($dbname, $link);
?>